//
//  main.cpp
//  lab9
//
//  Created by Oleh Haidar on 18.05.2020.
//  Copyright © 2020 Oleh Haidar. All rights reserved.
//

#include <iostream>
#include <vector>
namespace it_step
{
    template<typename T>
    class dynamic_array
    {
    public:
        dynamic_array(){
        };
        dynamic_array(size_t size){
            _data.reset();
            T* t = new T(size);
            size_of_data = size;
            std::unique_ptr<T[]> tmp(t);
            _data = std::move(tmp);
        };
        dynamic_array(size_t size, const T& defaultValue){
            _data.reset();
            T* t = new T(size);
            size_of_data = size;
            for(int i = 0; i < size; i++){
                t[i] = defaultValue;
            }
            std::unique_ptr<T[]> tmp(t);
            _data = std::move(tmp);
        };

        dynamic_array(const dynamic_array<T>& right);
        dynamic_array(dynamic_array<T>&& right);

        dynamic_array<T>& operator = (const dynamic_array<T>& right);
        dynamic_array<T>& operator = (dynamic_array<T>&& right);

        ~dynamic_array(){};

        T& at(size_t idx);
        const T& at(size_t idx) const;
        
        T& operator[](size_t idx)
           {
               if (idx >= size_of_data)
               {
                 //  assert(false);
                   throw std::out_of_range("\nInvalid idx - " + std::to_string(idx) + " due to incorrect size of array = " + std::to_string(size_of_data));
               }
               
               return _data.get()[idx];
           }

    
        const T& operator[](size_t idx) const
        {
            
            if (idx >= size_of_data)
            {
             //   assert(false);
                 throw std::out_of_range("\nInvalid idx - " + std::to_string(idx) + " due to incorrect size of array = " + std::to_string(size_of_data));
            }
            
            return _data.get()[idx];
        }

        size_t size();
        size_t capacity();

        void push_back(T&& value);
        void push_back(const T& value);

        T pop_back();
        void erase(T* value);
        void erase(size_t idx);

        void clear();
        void resize(size_t newSize);
        void reserve(size_t newCapacity);

        T* begin();
        const T* begin() const;
        T* end();
        const T* end() const;

    private:
        std::unique_ptr<T[]> _data;
        int size_of_data;
    };


    template<typename T = char>
    class dynamic_string
    {
    public:
        dynamic_string(){};
        dynamic_string(const T* value)
        {
            _data.push_back(*value);
        };
        
        void add(const T& value){
            _data.push_back(value);
        }
        
        dynamic_string(const dynamic_string<T>& right);
        
        dynamic_string(dynamic_string<T>&& right);

        dynamic_string<T>& operator=(const dynamic_string<T>& right);
        dynamic_string<T>& operator=(dynamic_string<T>&& right);

        T& operator[](size_t idx)
        {
            return _data[idx];
        };
        const T& operator[](size_t idx) const
        {
           return _data[idx];
        };
        size_t size()
        {
            return _data.size();
        };
        
        size_t capacity()
        {
            return _data.capacity();
        };

        dynamic_string<T> substr(size_t pos, size_t size);
        dynamic_array<dynamic_string<T>> split(T separator);
        
        dynamic_string<T>& operator+(const dynamic_string<T>& right);
        
        void operator+=(const dynamic_string<T>& right);
        bool operator==(const dynamic_string<T>& right);

        size_t size() const;
        size_t capacity() const;

        void resize(size_t newSize);
        void reserve(size_t newCapacity);

    private:
        std::vector<T> _data;
    };
}

int main(int argc, const char * argv[]) {
    try{
        it_step::dynamic_array <int> DynArray(15,2);
        std::cout << DynArray[44];
    }catch (const std::out_of_range& oor) {
       std::cerr << "Out of Range error: " << oor.what() << '\n';
    }catch (...){
        std::cerr << "Error" << '\n';
    }
    

    char char_tmp = 'c';
    it_step::dynamic_string <char> DynStr(&char_tmp);
    DynStr.add('d');
    DynStr.add('d');
    DynStr.add('d');
    DynStr.add('d');

    for(int i=0;i<DynStr.size();i++){
    std::cout << DynStr[i];
    }

    //char valueObj;
    //it_step::dynamic_string <char> DynStr(&valueObj);
    //std::unique_ptr<int[]> testData(new int[25]);
    
    return 0;
}

