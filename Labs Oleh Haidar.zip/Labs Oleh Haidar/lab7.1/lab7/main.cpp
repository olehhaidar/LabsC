//
//  main.cpp
//  lab7
//
//  Created by Oleh Haidar on 09.05.2020.
//  Copyright © 2020 Oleh Haidar. All rights reserved.
//

#include <iostream>
using namespace std;

class AudioManager
{
public:
    virtual void play() =0;
    virtual void pause()=0;
    virtual void stop()=0;
    virtual void resume()=0;
};

class PCAudioManager : public AudioManager
{
public:
    void play()  { std::cout << "play PC api\n"; }
    void pause() { std::cout << "pause PC api\n"; }
    void stop()  { std::cout << "stop PC api\n"; }
    void resume() { std::cout << "resume PC api\n"; }
};

class XboxAudioManager : public AudioManager
{
public:
    void play()  { std::cout << "play xbox api\n"; }
    void pause(){ std::cout << "pause xbox api\n"; }
    void stop() { std::cout << "stop xbox api\n"; }
    void resume(){ std::cout << "resume xbox api\n"; }
};

class PS4AudioManager : public AudioManager
{
public:
    void play()  { std::cout << "play ps4 api\n"; }
    void pause() { std::cout << "pause ps4 api\n"; }
    void stop()  { std::cout << "stop ps4 api\n"; }
    void resume(){ std::cout << "resume ps4 api\n"; }
};

class Creator
{
public:
    virtual AudioManager* factoryMethod() = 0;
};

class CreatorPCAudioManager : public Creator
{
public:
    AudioManager* factoryMethod()
    {
        return new PCAudioManager();
    }
};

class CreatorXboxAudioManager : public Creator
{
public:
    AudioManager* factoryMethod()
    {
        return new XboxAudioManager();
    }
};

class CreatorPS4AudioManager : public Creator
{
public:
    AudioManager* factoryMethod()
    {
        return new PS4AudioManager();
    }
};

enum class PlatformType
{
    PC, Xbox, PS4
};

int main()
{
    PlatformType plattype = PlatformType::PS4;
    CreatorPCAudioManager CreatorPC;
    CreatorXboxAudioManager CreatorXbox;
    CreatorPS4AudioManager CreatorPS4;
    Creator* pc = &CreatorPC;
    Creator* xbox = &CreatorXbox;
    Creator* ps4 = &CreatorPS4;
    if (plattype == PlatformType::PC) {
        AudioManager* audioman = pc->factoryMethod();

        cout <<"write smth\n";
        string a;
        cin >> a;
        if (a == "play") {
            audioman->play();
        }
        if (a == "pause") {
            audioman->pause();
        }
        if (a == "stop") {
            audioman->stop();
        }
        if (a == "resume") {
            audioman->resume();
        }

    }

    if (plattype == PlatformType::Xbox) {
        AudioManager* audioman = xbox->factoryMethod();
        
        cout <<"write smth\n";
        string a;
        cin >> a;
        if (a == "play") {
            audioman->play();
        }
        if (a == "pause") {
            audioman->pause();
        }
        if (a == "stop") {
            audioman->stop();
        }
        if (a == "resume") {
            audioman->resume();
        }
    }

    if (plattype == PlatformType::PS4) {
        AudioManager* audioman = ps4->factoryMethod();
        
        cout <<"write smth\n";
        string a;
        cin >> a;
        if (a == "play") {
            audioman->play();
        }
        if (a == "pause") {
            audioman->pause();
        }
        if (a == "stop") {
            audioman->stop();
        }
        if (a == "resume") {
            audioman->resume();
        }
    }


}
