
#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <algorithm>


using namespace std;


int main()
{
    vector <string> myVector = { "Eggs","Milk","Sugar","Chocolate","Flour" };

    cout << "-----------------------Vector---------------------------" << endl;
    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        cout << *i << endl;
    }

    vector<string>::iterator it;

    it = myVector.end();

    cout << "--------------------" << endl;

    //myVector.erase(it - 2);
    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        cout << *i << endl;
    }

    cout << "--------------------" << endl;

    it = myVector.begin();
    myVector.insert(it, "Coffee");
    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        cout << *i << endl;
    }

    cout << "--------------------" << endl;

    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        if (*i == "Milk") {
            //myVector.erase(i);
        }
    }
    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        cout << *i << endl;
    }

    cout << "--------------------" << endl;

    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        if (*i == "Eggs") {
            *i = "NULL";
        }
    }
    for (vector<string>::iterator i = myVector.begin(); i < myVector.end(); i++)
    {
        cout << *i << endl;
    }

    cout << "-----------------------List---------------------------" << endl;

    list<string> myList;
    myList.push_back("Eggs");
    myList.push_back("Milk");
    myList.push_back("Sugar");
    myList.push_back("Chocolate");
    myList.push_back("Flour");
    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        std::cout << *i << endl;
    }

    cout << "--------------------" << endl;

    myList.pop_front();
    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        std::cout << *i << endl;
    }

    cout << "--------------------" << endl;

    myList.push_front("Coffee");
    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        std::cout << *i << endl;
    }

    cout << "--------------------" << endl;

    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        if (*i == "Sugar") {
            //myList.erase(i);
            myList.insert(i, "Honey");
        }
    }
    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        std::cout << *i << endl;
    }

    cout << "-------------------" << endl;

    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        if (*i == "Milk") {
            myList.insert(i, "baking powder");
        }
    }
    for (auto i = myList.begin(); i != myList.end(); i++)
    {
        std::cout << *i << endl;
    }

    cout << "-----------------------Copy list to vector---------------------------" << endl;

    list<string> myList2;
    vector <string> myVector2;
    vector<string>::iterator it2;
    it2 = myVector2.begin();
    myList2.push_back("Eggs");
    myList2.push_back("Milk");
    myList2.push_back("Sugar");
    myList2.push_back("Chocolate");
    myList2.push_back("Flour");

    for (auto i = myList2.begin(); i != myList2.end(); i++)
    {
        myVector2.insert(myVector2.begin(), *i);
    }
    for (vector<string>::iterator i = myVector2.begin(); i < myVector2.end(); i++)
    {
        cout << *i << endl;
    }
    cout << "-----------------------sorting vector---------------------------" << endl;
    std::sort(myVector2.begin(), myVector2.end());
    for (vector<string>::iterator i = myVector2.begin(); i < myVector2.end(); i++)
    {
        cout << *i << endl;
    }
    return 0;
}
