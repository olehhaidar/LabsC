//
//  main.cpp
//  Addingto7
//
//  Created by Oleh Haidar on 14.05.2020.
//  Copyright © 2020 Oleh Haidar. All rights reserved.
//

#include <iostream>
#include <fstream>
#include "vector"

class IMediaFile
{
public:
    virtual ~IMediaFile() = default;
    virtual void create() = 0;
    virtual const std::string& name() const = 0;
};

class AudioManager
{
protected:
    AudioManager() = default;
public:
    AudioManager(const AudioManager& a) = delete;
    AudioManager(AudioManager&& a) = delete;
    AudioManager& operator=(const AudioManager& a) = delete;
    AudioManager& operator=( AudioManager&& a) = delete;
    virtual void play(const IMediaFile& sound) const { std::cout << "play " << sound.name() << " win api\n"; }
    virtual void play(const std::string& sound) const { std::cout << "play " << sound << " win api\n"; }
    virtual void pause() const { std::cout << "pause win api\n"; }
    virtual void stop() const { std::cout << "stop win api\n"; }
    virtual void resume() const {std::cout << "resume win api\n"; }
};


class AudioManagerPc : public AudioManager
{
public:
    void play(const std::string& sound) const override{ std::cout << "play " << sound << " PC win api\n"; }
    void pause() const override { std::cout << "pause PC win api\n"; }
    void stop() const override{ std::cout << "stop PC win api\n"; }
    void resume() const override {std::cout << "resume PC win api\n"; }
};


class AudioManagerXbox : public AudioManager
{
public:
    void play(const std::string& sound) const override { std::cout << "play " << sound << " Xbox win api\n"; }
    void pause() const override { std::cout << "pause Xbox win api\n"; }
    void stop() const override { std::cout << "stop Xbox win api\n"; }
    void resume() const override {std::cout << "resume Xbox win api\n"; }
};


class AudioManagerPS4 : public AudioManager
{
public:
    void play(const std::string& sound) const override { std::cout << "play " << sound << " PS4 win api\n"; }
    void pause() const override{ std::cout << "pause PS4 win api\n"; }
    void stop() const override{ std::cout << "stop PS4 win api\n"; }
    void resume() const override{std::cout << "resume PS4 win api\n"; }
};


enum class PlatformType
{
    PC
    , XBOX
    , PS4
};


class AudioManagerFactory
{
public:
    static std::unique_ptr<AudioManager> create(PlatformType type)
    {
        if(type == PlatformType::PC)
            return std::unique_ptr<AudioManager>(new AudioManagerPc);
        else if(type == PlatformType::XBOX)
            return std::unique_ptr<AudioManager>(new AudioManagerXbox);
        else if(type == PlatformType::PC)
            return std::unique_ptr<AudioManager>(new AudioManagerPS4);
        else
        {
            std::cout << "Undefined platform type. Returning nullptr\n";
            return std::unique_ptr<AudioManager>(nullptr);
        }
    };
};


class IMediaFileWav : public IMediaFile
{
private:
      std::string file_name;
public:
    IMediaFileWav() = default;
    IMediaFileWav(const std::string& file_name) : file_name(file_name){}
    const std::string& name() const override { return file_name;}
    void create() override
    {
        std::ofstream f(file_name);
        f.close();
    }
};


class IMediaFileMP3 : public IMediaFile
{
    private:
          std::string file_name;
    public:
        IMediaFileMP3() = default;
        IMediaFileMP3(const std::string& file_name): file_name(file_name){}
        const std::string& name() const override { return file_name;}
        void create() override
        {
            std::ofstream f(file_name);
            f.close();
        }
};


class IMediaFileDOLBY  : public IMediaFile
{
    private:
          std::string file_name;
    public:
        IMediaFileDOLBY() = default;
    IMediaFileDOLBY(const std::string& file_name) : file_name(file_name){}
        const std::string& name() const override { return file_name;}
        void create() override
        {
            std::ofstream f(file_name);
            f.close();
        }
};


class MediaFileReader : public IMediaFile
{
public:
    static std::unique_ptr<IMediaFile> read(const std::string& filename)
    {
        if(filename.find(".wav") != std::string::npos)
        {
            std::unique_ptr<IMediaFile> wav = std::unique_ptr<IMediaFile>(new IMediaFileWav(filename));
            wav->create();
            return wav;
        }
       else if(filename.find(".DOLBY") != std::string::npos)
        {
            std::unique_ptr<IMediaFile> dolby = std::unique_ptr<IMediaFile>(new IMediaFileDOLBY(filename));
            dolby->create();
            return dolby;
        }
        else if(filename.find(".mp3") != std::string::npos)
        {
            std::unique_ptr<IMediaFile> mp3 = std::unique_ptr<IMediaFile>(new IMediaFileMP3(filename));
            mp3->create();
            return mp3;
        }
        else
        {
            std::cout << "Undefined type of file. Returning nullptr\n";
            return std::unique_ptr<IMediaFile>(nullptr);
        }
    }
};


int main(){}

