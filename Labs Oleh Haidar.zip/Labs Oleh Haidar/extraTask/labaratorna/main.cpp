#include <iostream>
#include <vector>
#include <string>


class SomeInts
{
public:
    SomeInts(){
        
    };
    SomeInts(std::vector<int>& data){
        m_data = data;
    };
    ~SomeInts(){
    };
    
    bool AddItemToBack(int data){
        m_data.push_back(data);
        return true;
    };
    bool AddItemToBeging(int data){
        m_data.insert(m_data.begin(), data);
        return true;
    };
    bool RemoveItemAt(int number){
        if(number < 1 || m_data.size()<number){
            return false;
        }
        m_data.erase(m_data.begin() + (number - 1));
        return true;
    };
    std::string toString()
    {
        std::string str = "";
        for(std::vector<int>::iterator it = m_data.begin(); it<m_data.end(); it++)
        {
            str += std::to_string(*it) + "\t";
        }
        return str;
    };
    void SortItems()
    {
        std::sort(m_data.begin(), m_data.end());
    }
    
protected:
    std::vector<int> m_data;
};

int main(int argc, const char * argv[]) {
    
    SomeInts ints;
    ints.AddItemToBack(22);
    ints.AddItemToBack(2);
    ints.AddItemToBack(12);
    ints.AddItemToBack(19);
    ints.AddItemToBack(41);
    ints.AddItemToBack(1);
    ints.AddItemToBack(0);
    ints.AddItemToBack(55);
    ints.AddItemToBack(4);
    ints.AddItemToBack(11);
    ints.AddItemToBack(7);
    ints.AddItemToBack(99);
    ints.AddItemToBack(65);
    
    ints.SortItems();
    std::cout << ints.toString() << std::endl;
}
