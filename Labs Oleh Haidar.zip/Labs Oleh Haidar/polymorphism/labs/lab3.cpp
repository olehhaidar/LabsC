#include <stdio.h>
using namespace std;
int main(void)
{
    int *pa = new int;
    cout << "*pa = \t" <<*pa << endl;
    cout << "pa = \t" <<pa << endl;
}
