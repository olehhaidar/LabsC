#include <iostream>
using namespace std;

class Circul{
    public:
    Circul(){
        cout << "class car" << endl;
    }
};
class Wheel : public Circul{
    public:
    Wheel():Circul(){
        cout << "class wheel" << endl;
    }
};
class Glass : Circul{
    public:
    Glass(){
        cout << "class glass" << endl;
    }
};

class Chair{
    public:
    Chair(){
        cout << "class chair" << endl;
    }
};

class Car{
    public:
    Wheel wh;
    Glass gl;
    Chair ch;
    
    Car()//: wh(), ch(), gl()
    {
        cout << "class Car" << endl;
    }
    virtual void display(){
        cout << "display Car" << endl;
    }
    void paint(){
        cout << "paint Car" << endl;
    }
};

class Track : public Car{
    int y;
    public:
     Track():Car(){
        cout << "class Track" << endl;
    }
    virtual void display(){
        cout << "display Track" << endl;
    }
    void paint(){
        cout << "paint Track" << endl;
    }
};

int main(void) {
    
    Car* c1 = new Track();
    Car* c2 = new Car();

    c1->display();
    c2->display();
    
    c1->paint();
    c2->paint();

}
