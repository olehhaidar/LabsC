//
//  lab3.hpp
//  poly
//
//  Created by Oleh Haidar on 19.02.2020.
//  Copyright © 2020 Oleh Haidar. All rights reserved.
//

#ifndef lab3_hpp
#define lab3_hpp

#include <stdio.h>

#endif /* lab3_hpp */
