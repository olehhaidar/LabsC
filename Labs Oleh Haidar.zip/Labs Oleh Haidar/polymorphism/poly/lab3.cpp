//
//  lab3.cpp
//  poly
//
//  Created by Oleh Haidar on 19.02.2020.
//  Copyright © 2020 Oleh Haidar. All rights reserved.
//

#include "lab3.hpp"
