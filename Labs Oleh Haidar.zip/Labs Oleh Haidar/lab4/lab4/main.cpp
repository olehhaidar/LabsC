#include <iostream>
#include <vector>

//#include <format>

#include <sstream>
#include <iostream>
#include <iomanip>

using namespace std;


class SomeObject
{
    
public:
    SomeObject(int id, const string name, int price, string provider, int quantity,string term)
    :m_id(id), m_name(name), m_price(price), m_provider(provider), m_quantity(quantity), m_term(term)
    {}
    
    SomeObject(){}

    int getId() const
    {
        return m_id;
    }
    
    const string& getName() const
    {
        return m_name;
    }
    
    int getPrice() const
    {
        return m_price;
    }
    
    const string& getProvider() const
    {
        return m_provider;
    }
    
    int getQuantity() const
    {
        return m_quantity;
    }
    
    const string& getTerm() const
    {
           return m_term;
    }
    
    bool setPrice(int price){
        if(price > 0){
            m_price = price;
            return true;
        }
        return false;
    }
    
    bool setProvider(string provider){
        m_provider = provider;
        return true;
    }
    
    bool setQuantity(int quantity){
        if(quantity >= 0){
            m_quantity = quantity;
            return true;
        }
        return false;
    }
    
    string toString()
    {
        return to_string(m_id) + " - ID\n\t" + m_name + " - Name\n\t" + to_string(m_price) + " - Price\n\t" + m_provider + " - Provider\n\t" + to_string(m_quantity)+ " - Quantity\n\t" + m_term + " - Term\n\t";
        
   //   return format("{}, {}, {}, {}, {},", m_id, m_name, m_price, m_provider, m_quantity, m_term);
    }
    
private:
    int m_id;
    string m_name;
    int m_price;
    string m_provider;
    int m_quantity;
    string m_term;
    
public:
    bool operator< (const SomeObject& obj) const
    {
        return m_name < obj.getName();
    }
};

class Controller
{
    
public:
    void addObject(const SomeObject& obj)
    {
        objects.push_back(obj);
        sort(objects.begin(), objects.end());
    }
    
    SomeObject* findById(int id)
    {
        for(auto& obj : objects)
        {
            if(obj.getId() == id)
            {
                return &obj;
            }
        }
        return nullptr;
    }
    
    bool deleteById(int id)
       {
         //  std::remove_if(objects.begin(), objects.end(), [](SomeObject& obj) {return obj.getId() == i;});
           
           for(vector<SomeObject>::iterator it = objects.begin(); it != objects.end();)
           {
               if(it->getId() == id)
               {
                   objects.erase(it);
               }else{
                   it++;
               }
           }
           return true;
       }
    
    
    vector<SomeObject> findByName(const string& name)
    {
        vector<SomeObject> tempObj;
            for(auto& obj : objects)
            {
                if(obj.getName() == name)
                {
                    tempObj.push_back(obj);
                }
            }
            return tempObj;
    }
    
    vector<SomeObject> findByProvider(const string& provider)
     {
         vector<SomeObject> tempObj;
             for(auto& obj : objects)
             {
                 if(obj.getProvider() == provider)
                 {
                     tempObj.push_back(obj);
                 }
             }
             return tempObj;
     }
    
    vector<SomeObject> findByTerm(const string& term)
    {
        vector<SomeObject> tempObj;
            for(auto& obj : objects)
            {
                if(obj.getTerm() < term)
                {
                    tempObj.push_back(obj);
                }
            }
            return tempObj;
    }
    
    int deleteByTerm(const string& term)
      {
          int temp = 0;
          for( vector<SomeObject>::iterator it = objects.begin(); it != objects.end();)
                    {
                        if(it->getTerm() < term)
                        {
                            objects.erase(it);
                            temp++;
                        }else{
                            it++;
                        }
                    }
          return temp;
      }
    
    string printList()
    {
        return printList(objects);
    }
    
    string printList(vector<SomeObject>& vec)
    {
     //   string temp = "\nID\t Name\t Price\t Provider\t Quantity\t Term\n\n";
        string temp = "";
        for(auto& obj : vec)
        {
            temp += obj.toString() + "\n";
        }
        return temp;
    }

private:
    vector<SomeObject> objects;
    
};

int main(int argc, const char * argv[])
{
    Controller controller;
    int nextId = 0;
    
    controller.addObject({++nextId, "Laptop", 998, "Petro", 11, "2012-05-22"});
    controller.addObject({++nextId, "Mouse", 99, "Dmitro", 7, "2017-07-22"});
    controller.addObject({++nextId, "Keyboard", 400, "Pavlo", 100, "2222-22-22"});
    controller.addObject({++nextId, "Headsets", 264, "Max", 71, "2019-05-21"});
    controller.addObject({++nextId, "Phone", 888, "Victor", 19, "2019-12-11"});
    controller.addObject({++nextId, "Headsets", 777, "Vlad", 71, "2013-05-20"});
    controller.addObject({++nextId, "Phone", 588, "Victor", 19, "2019-12-11"});
    
    while(true)
    {
        cout << "\nSelect operation:\n 1 - ADD\n 2 - FINDBYID\n 3 - FINDBYPROVIDER\n 4 - FINDBYNAME\n 5 - FINDBYTERM\n 6 - EDIT\n 7 - DELETEBYID\n"
        " 8 - DELETEBYTERM\n 9 - LIST OF GOODS\n 10 - EXIT" << endl;
    
        int op;
        cin >> op;
        
        if(op == 1)
        {
            string name("");
            int price = 0;
            string provider = "";
            int quantity = 0;
            string term = "";
            
            cout << "Enter product name" << endl;
            cin  >> name;
            cout << "Enter price" << endl;
            cin >> price;
            cout << "Enter provider" << endl;
            cin >> provider;
            cout << "Enter quantity" << endl;
            cin >> quantity;
            cout << "Enter term YYYY-MM-DD" << endl;
            cin >> term;
            
            SomeObject objec;
            if(!objec.setProvider(provider)){
                cout << "Please reset provider (invalid provider)";
            }
            if(!objec.setPrice(price)){
                cout << "Please reset price (invalid price)";
            }
           if(!objec.setQuantity(quantity)){
                cout << "Please reset quantity (invalid quantity)";
            }
         
       //     controller.addObject(objec);
            controller.addObject({++nextId, name, price, provider, quantity, term});
            
        }else if(op == 2){
            int id = 0;
            cout << "Enter id" << endl;
            cin >> id;
            auto obj = controller.findById(id);
            if(obj)
            {
                cout << obj->toString() << endl;
            }
        }else if(op == 3){
            string prov = "";
            cout << "Enter provider name" << endl;
            cin >> prov;
            vector<SomeObject> tmpVec = controller.findByProvider(prov);
            if(tmpVec.size() > 0)
            {
                cout << controller.printList(tmpVec) << endl;
            }else{
                cout<<"Not found" << endl;
            }
            
        }else if(op == 4){
            string nam = "";
            cout << "Enter product name" << endl;
            cin >> nam;
            vector<SomeObject> tmpVec = controller.findByName(nam);
            if(tmpVec.size() > 0)
                cout << controller.printList(tmpVec) << endl;
            else
                cout<<"Not found"<< endl;
                
        }else if(op == 5){
            string ter = "";
            cout << "Enter normal term" << endl;
            cin >> ter;
            vector<SomeObject> tmpVec = controller.findByTerm(ter);
            if(tmpVec.size() > 0)
                cout << controller.printList(tmpVec) << endl;
            else
                cout<<"Not found"<< endl;
            
        }else if(op == 6){
            int id = 0;
            cout << "Enter id" << endl;
            cin >> id;
            auto obj = controller.findById(id);
            
            if(obj)
            {
                int price = 0, quant = 0;
                string provider = "";
                cout << obj->toString() << endl;
                bool bOK = false;
                
                do{
                    cout << "Enter new price" << endl;
                    cin >> price;
                    bOK = obj->setPrice(price);
                    if(!bOK){
                        cout << "Failed! Invalid price"<<endl;
                    }
                } while(!bOK);
                
                do{
                    cout << "Enter new provider" << endl;
                    cin >> provider;
                    bOK = obj->setProvider(provider);
                    if(!bOK){
                        cout << "Failed! Invalid price"<<endl;
                   }
                } while(!bOK);
                
                do{
                    cout << "Enter new quantity" << endl;
                    cin >> quant;
                    bOK = obj->setQuantity(quant);
                    if(!bOK){
                        cout << "Failed! Invalid price"<<endl;
                    }
                } while(!bOK);
                
                cout << "\nSuccessful\nNew data :  " +  obj->toString()  << endl;
               
            }else{
                cout << "Not found" << endl;
            }
            
        }else if(op == 7){
            int id = 0;
            cout << "Enter id" << endl;
            cin >> id;
            bool bDel = controller.deleteById(id);
            cout << ((bDel) ? "Deleted successful\n" : "Not found\n") << endl;
            
        }else if(op == 8){
            string date = "";
            cout << "Enter date in format YYYY-MM-DD" << endl;
            cin >> date;
            int delQuant = controller.deleteByTerm(date);
            
            if(delQuant > 0)
            {
                cout << "Deleted successful - " << delQuant << endl;
            }else{
                cout << "Not found\n" << endl;
            }
            
        }else if(op == 9){
            cout << controller.printList() << endl;
            
        }else if(op == 10){
             return 0;
        }
    }
}

